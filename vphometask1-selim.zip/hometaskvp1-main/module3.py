
import os


f = open("123.txt", "a+")
f.write("\nNew Line")
f.close()